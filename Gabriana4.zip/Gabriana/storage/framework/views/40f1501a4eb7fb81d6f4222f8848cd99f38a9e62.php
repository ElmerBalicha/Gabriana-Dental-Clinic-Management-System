<?php $__env->startSection('content'); ?>

        <section class="content-header">
            <h1>
                Create Service
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/assistant')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class=""><a href="<?php echo e(url('/assistant/service')); ?>">Services</a></li>
                <li class="active">Create</li>
            </ol>
        </section>
        <div class="well">
        <?php echo Form::open(['action' => 'Assistant\\ServicesController@store', 'method' => 'POST']); ?>

            <div class="form-group">
                <?php echo e(Form::label('servName', 'Service Name')); ?>

                <?php echo e(Form::text('servName', '', ['class' => 'form-control', 'placeholder' => 'Enter Service'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('price', 'Price')); ?>

                <?php echo e(Form::text('price', '', ['class' => 'form-control', 'placeholder' => 'Enter Price'])); ?>

            </div>
            <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.assistantLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>