<?php $__env->startSection('content'); ?>

    <div class="content-wrapper" style="min-height: 1126px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo e($patient->name); ?>

      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="/patient">Records</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Patient Information</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td>Name :</td>
                            <td><?php echo e($patient->name); ?></td>
                        </tr>
                          <tr>
                            <td>Address :</td>
                            <td><?php echo e($patient->address); ?></td>
                          </tr>
                          <tr>
                            <td>Occupation :</td>
                            <td><?php echo e($patient->occupation); ?></td>
                          </tr>
                          <tr>
                              <td>Contact Number :</td>
                            <td><?php echo e($patient->patientTelNo); ?></td>
                          </tr>
                          <tr>
                            <td>Civil Status</td>
                            <td><?php echo e($patient->status); ?></td>
                          </tr>
                          <tr>
                              <td>Date of Birth :</td>
                            <td><?php echo e($patient->birthDate); ?></td>
                          </tr>
                          <tr>
                              <td>Age :</td>
                            <td><?php echo e($patient->age); ?></td>
                          </tr>
                          <tr>
                              <td>Gender :</td>
                            <td><?php echo e($patient->sex); ?></td>
                          </tr>
                          <tr>
                              <td>Medical Conditions :</td>
                            <td><?php echo e($patient->medconditions); ?></td>
                          </tr>
                          <tr>
                              <td>Allergies :</td>
                            <td><?php echo e($patient->allergies); ?></td>
                            </tr>
                          <tr>
                            <td>Balance :</td>
                            <td><?php echo e($patient->balance); ?></td>
                            </tr>
                          </tr>
                          <tr>
                              <td>Patient Status :</td>
                            <td><?php echo e($patient->patStatus); ?></td>
                          </tr>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
                <a href="admin/patient" class="btn btn-default">Cancel</a>
                <a href="admin/patient/<?php echo e($patient->patID); ?>/edit" class="btn btn-primary pull-right">Edit</a>
            </div>
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>