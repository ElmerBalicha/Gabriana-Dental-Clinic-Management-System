<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Checkout
        </h1>
        <ol class="breadcrumb">
            <li><a href="/assistant"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Schedule</li>
        </ol>
        <h4><?php echo e($schedule->patient->name); ?></h4>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body">
                        <?php if($errors->any()): ?>
                            <ul class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <?php echo Form::open(['action' => 'Assistant\\PatientsController@store', 'method' => 'POST']); ?>

                        <div class="form-group">
                            <?php echo e(Form::label('teethAffected', 'Teeth Affected')); ?>

                            <?php echo e(Form::text('teethAffected', '', ['class' => 'form-control', 'placeholder' => 'Teeth Code (e.g. R1)'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('service', 'Service Rendered')); ?>

                            <?php echo e(Form::text('service', '', ['class' => 'form-control', 'placeholder' => 'Teeth Whitening etc.'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('servicePrice', 'Price of Services')); ?>

                            <?php echo e(Form::text('servicePrice', '', ['class' => 'form-control', 'placeholder' => 'Total price of services'])); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('payment', 'Payment')); ?>

                            <?php echo e(Form::text('payment', '', ['class' => 'form-control', 'placeholder' => 'Payment Amount'])); ?>

                        </div>
                        
                        
                    <?php echo Form::close(); ?>

                    </div>
                                           
                    <div class="box-footer">
                        <a href="<?php echo e(url('/assistant/schedules')); ?>" title="Back"><button class="btn btn-warning"> Cancel</button></a>
                    <div class="pull-right">
                <?php echo Form::open(['action' => ['Assistant\SchedulesController@destroy', $schedule->schedId], 'method' => 'post', 'class' => 'pull-left' ]); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Mark as Done', ['class'=>'btn btn-success pull-right'])); ?>

                <?php echo Form::close(); ?>

                    </div>  
                
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.assistantLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>