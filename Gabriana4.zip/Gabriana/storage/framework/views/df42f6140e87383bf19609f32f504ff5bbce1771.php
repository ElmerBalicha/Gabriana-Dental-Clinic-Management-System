<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 1126px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Edit Patient
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="/patient">Records</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <!-- box-header -->
                    <div class="box box-info">
                        <div class="box-header with-border">
                        <h3 class="box-title">Edit Patient</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <?php echo Form::open(['action' => ['PatientController@update', $patient->id], 'method' => 'POST', 'class' => 'form-horizontal']); ?>

                        <div class="box-body">
                            <div class="form-group">
                                <?php echo e(Form::label('fname', 'First Name', ['class' => 'col-sm-2 control-label'])); ?>

                                <div class="col-sm-10">
                                    <?php echo e(Form::text('fname', $patient->fname, ['class' => 'form-control', 'placeholder' => 'First Name'])); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('lname', 'Last Name', ['class' => 'col-sm-2 control-label'])); ?>

                                <div class="col-sm-10">
                                    <?php echo e(Form::text('lname', $patient->lname, ['class' => 'form-control', 'placeholder' => 'Last Name'])); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('mname', 'M.I', ['class' => 'col-sm-2 control-label'])); ?>

                                <div class="col-sm-10">
                                    <?php echo e(Form::text('mname', $patient->mname, ['class' => 'form-control', 'placeholder' => 'M.I'])); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('age', 'Age', ['class' => 'col-sm-2 control-label'])); ?>

                                <div class="col-sm-10">
                                    <?php echo e(Form::text('age', $patient->age, ['class' => 'form-control', 'placeholder' => 'Age'])); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('address', 'Address', ['class' => 'col-sm-2 control-label'])); ?>

                                <div class="col-sm-10">
                                    <?php echo e(Form::text('address', $patient->address, ['class' => 'form-control', 'placeholder' => 'Address'])); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('status', 'Status', ['class' => 'col-sm-2 control-label'])); ?>

                                <div class="col-sm-10">
                                    <?php echo e(Form::text('status', $patient->status, ['class' => 'form-control', 'placeholder' => 'Status'])); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('contactNo', 'Contact No.', ['class' => 'col-sm-2 control-label'])); ?>

                                <div class="col-sm-10">
                                    <?php echo e(Form::text('contactNo', $patient->contactNo, ['class' => 'form-control', 'placeholder' => 'Contact No.'])); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('nationality', 'Nationality', ['class' => 'col-sm-2 control-label'])); ?>

                                <div class="col-sm-10">
                                    <?php echo e(Form::text('nationality', $patient->nationality, ['class' => 'form-control', 'placeholder' => 'Nationality'])); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('dentist', 'Dentist', ['class' => 'col-sm-2 control-label'])); ?>

                                <div class="col-sm-10">
                                    <?php echo e(Form::text('dentist', $patient->dentist, ['class' => 'form-control', 'placeholder' => 'Dentist'])); ?>

                                </div>
                            </div>
                            <?php echo e(Form::hidden('_method', 'PUT')); ?>

                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <a href="/patient" class="btn btn-default">Cancel</a>
                            <?php echo e(Form::submit('Submit', ['class' => 'btn btn-info pull-right'])); ?>

                        </div>
                        <!-- /.box-footer -->
                    <?php echo Form::close(); ?>

                <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>