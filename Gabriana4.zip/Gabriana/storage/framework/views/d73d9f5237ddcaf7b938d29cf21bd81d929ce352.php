<?php $__env->startSection('content'); ?>

    <div class="content-wrapper" style="min-height: 1126px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo e($patient->lname); ?>, <?php echo e($patient->fname); ?> <?php echo e($patient->mname); ?>.
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="/patient">Records</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Basic Information</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td style="width:10%">First Name</td>
                            <td><?php echo e($patient->fname); ?></td>
                            <td style="width:10%">Age</td>
                            <td><?php echo e($patient->age); ?></td>
                            <td style="width:10%">Contact No.</td>
                            <td><?php echo e($patient->contactNo); ?></td>
                        </tr>
                        <tr>
                            <td>M.I</td>
                            <td><?php echo e($patient->mname); ?></td>
                            <td>Address</td>
                            <td><?php echo e($patient->address); ?></td>
                            <td>Nationality</td>
                            <td><?php echo e($patient->nationality); ?></td>
                        </tr>
                        <tr>
                            <td>Last Name</td>
                            <td><?php echo e($patient->lname); ?></td>
                            <td>Status</td>
                            <td><?php echo e($patient->status); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <a href="/patient/<?php echo e($patient->id); ?>/edit" class="btn btn-primary pull-left">Edit</a>
              <?php echo Form::open(['action' => ['PatientController@destroy', $patient->id], 'method' => 'POST', 'class' => 'pull-left' ]); ?>

                  <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                  <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

              <?php echo Form::close(); ?>

            </div>
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>