<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/admin', 'PagesController@admin')->name('admin');
Route::get('/admin2', 'PagesController@admin2')->name('admin2');
Route::get('/', 'PagesController@log')->name('');
Route::get('/try', 'PagesController@trypage')->name('try');
Route::get('/top-nav', 'PagesController@topnav')->name('top-nav');
Route::get('/collapsed-sidebar', 'PagesController@collapsedsidebar')->name('collapsed-sidebar');
Route::get('/fixed', 'PagesController@fixed')->name('fixed');
Route::get('/boxed', 'PagesController@boxed')->name('boxed');
Route::get('/records', 'RecordsController@records')->name('records');
Route::get('/inventory', 'PagesController@inventory')->name('inventory');
Route::get('/datatibil', 'PagesController@datatibil')->name('datatibil');