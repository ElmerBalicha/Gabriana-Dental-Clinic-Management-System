<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Create Patient
            </h1>
            <ol class="breadcrumb">
                <li><a href="/home"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="">Records</li>
                <li class="active">Create</li>
            </ol>
        </section>
        <div class="well">
        <?php echo Form::open(['action' => 'PatientsController@store', 'method' => 'POST']); ?>

            <div class="form-group">
                <?php echo e(Form::label('name', 'Name')); ?>

                <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'First name followed by Last Name'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('address', 'Address')); ?>

                <?php echo e(Form::text('address', '', ['class' => 'form-control', 'placeholder' => '#68 Corner General Luna road'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('occupation', 'Occupation')); ?>

                <?php echo e(Form::text('occupation', '', ['class' => 'form-control', 'placeholder' => 'Enter Occupation'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('patientTelNo', 'Telephone number')); ?>

                <?php echo e(Form::text('patientTelNo', '', ['class' => 'form-control', 'placeholder' => '09036232265'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('status', 'Civil Status')); ?>

                <?php echo e(Form::text('status', '', ['class' => 'form-control', 'placeholder' => 'Enter Civil Status'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('birthdate', 'Date of Birth')); ?>

                <?php echo e(Form::text('birthdate', '', ['class' => 'form-control', 'placeholder' => 'Year-month-day Ex. 1997-3-28'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('age', 'Age')); ?>

                <?php echo e(Form::text('age', '', ['class' => 'form-control', 'placeholder' => '18'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('sex', 'Sex')); ?>

                <?php echo e(Form::text('sex', '', ['class' => 'form-control', 'placeholder' => 'Male or Female'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('medConditions', 'Medical Conditions')); ?>

                <?php echo e(Form::text('medConditions', '', ['class' => 'form-control', 'placeholder' => 'Pulmonary Hypertension, etc.'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('allergies', 'Allergies')); ?>

                <?php echo e(Form::text('allergies', '', ['class' => 'form-control', 'placeholder' => 'Peanut, Dust, etc.'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('balance', 'Balance')); ?>

                <?php echo e(Form::text('balance', '', ['class' => 'form-control', 'placeholder' => '0'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('patStatus', 'Patient Status')); ?>

                <?php echo e(Form::text('patStatus', '', ['class' => 'form-control', 'placeholder' => 'Active'])); ?>

            </div>
            <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

        <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>