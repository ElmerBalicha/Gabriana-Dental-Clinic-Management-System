<?php $__env->startSection('content'); ?>

        <section class="content-header">
            <h1>
                Add inventory item
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/assistant')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class=""><a href="<?php echo e(url('/assistant/inventory')); ?>">Inventory</a></li>
                <li class="active">Add Inventory</li>
            </ol>
        </section>
        <div class="well">
            <?php echo Form::open(['action' => ['Assistant\\InventoryController@update', $inventory->invID], 'method' => 'POST']); ?>

            
            <div class="form-group">
                <?php echo e(Form::label('invName', 'Name')); ?>

                <?php echo e(Form::text('invName', $inventory->invName, ['class' => 'form-control', 'placeholder' => 'Inventory Name'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::label('additional', 'Additional')); ?>

                    <?php echo e(Form::number('additional', '', ['class' => 'form-control', 'placeholder' => 'Additional Quantity'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::label('quantity', 'Quantity')); ?>

                    <?php echo e(Form::number('quantity', $inventory->quantity, ['class' => 'form-control', 'placeholder' => 'Initial Quantity'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::label('low_stock_quantity', 'Low Stock Quantity')); ?>

                    <?php echo e(Form::text('low_stock_quantity', $inventory->low_stock_quantity, ['class' => 'form-control', 'placeholder' => 'Enter the Low Stock Quantity'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::label('unit', 'Unit Category')); ?>

                    <?php echo e(Form::text('unit', $inventory->unit, ['class' => 'form-control', 'placeholder' => 'Enter the Unit category (e.g. Box, Pieces)'])); ?>

            </div>
                        
            <?php echo e(Form::hidden('_method', 'PUT')); ?>

            <div class="box-footer">
                <a href="<?php echo e(url('/assistant/inventory')); ?>" class="btn btn-default">Cancel</a>
                <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary pull-right'])); ?>

            </div>
            <?php echo Form::close(); ?>

        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.assistantLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>