<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <!-- Left side column. contains the logo and sidebar -->
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>
                    Patient Records
                </h1>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active">Records</li>
                </ol>
            </section>

      <!-- Patient Records Division -->
      <hr>
      <div class="well">
            <a href="/patient/create" class="btn btn-primary">Create New Patient</a>
            <table id="example2" class="table table-bordered table-hover">
            <thead>
                    <tr>
                        <th>Patient Name</th>
                        <th>Contact No.</th>
                        <th>Dentist</th>
                        <th>Last Visit</th>
                        <th>Operation</th>
                        <th style="width: 25%">Options</th>
                    </tr>
                    
              </thead>
              <tbody>
                <?php if(count($patients) > 0): ?>
                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($patient->lname); ?>, <?php echo e($patient->fname); ?> <?php echo e($patient->mname); ?>.</td>
                        <td><?php echo e($patient->contactNo); ?></td>
                        <td><?php echo e($patient->dentist); ?></td>
                        <td></td>
                        <td></td>
                        <td>
                        <a href="/patient/<?php echo e($patient->id); ?>" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> Profile</a>
                        <a class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> History</a>
                        <a class="btn btn-danger btn-xs"><i class="fa fa-trash"></i> Deactivate</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>

                <?php endif; ?>
              </tbody>
      </div> <!-- end of wrapper -->
      <!-- end of Patient Records Division -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>