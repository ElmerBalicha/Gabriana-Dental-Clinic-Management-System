<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class pagesController extends Controller
{
    public function admin()
    {
        return view('pages.admin');
    }

    public function admin2()
    {
        return view('pages.admin2');
    }

    public function log()
    {
        return view('auth.login');
    }

    public function trypage()
    {
        return view('pages.try');
    }

    public function topnav()
    {
        return view('nav.top-nav');
    }

    public function collapsedsidebar()
    {
        return view('nav.collapsed-sidebar');
    }

    public function boxed()
    {
        return view('nav.fixed');
    }

    public function fixed()
    {
        return view('nav.boxed');
    }

    public function inventory()
    {
        return view('pages.inventory');
    }

    public function datatibil()
    {
        return view('pages.datatibil');
    }
}
