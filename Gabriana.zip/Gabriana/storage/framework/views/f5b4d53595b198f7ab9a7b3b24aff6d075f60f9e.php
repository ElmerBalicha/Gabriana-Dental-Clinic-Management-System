<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name', 'Gabriana DCMS')); ?></title>

    <link href="<?php echo e(asset('design/datatable/css/datatables.bootstrap.css')); ?>" rel="stylesheet">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('design/datatable/css/bootstrap.min.css')); ?>" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('inc.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="<?php echo e(asset('design/datatable/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('design/datatable/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('design/datatable/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('design/datatable/js/datatables.bootstrap.js')); ?>"></script>
</body>
</html>